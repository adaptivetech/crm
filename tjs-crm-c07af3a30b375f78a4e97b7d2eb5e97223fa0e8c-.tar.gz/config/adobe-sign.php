<?php

return [

    'clientId' => '',

    'clientSecret' => '',

    'redirectUri' => '',

    'scope' => [ 
        "user_login:account",
        "agreement_read:account",
        "agreement_write:account",
        "agreement_send:account",
        "library_read:account",
        "library_write:account",
        "workflow_read:account",
        "workflow_write:account"
    ]

];
